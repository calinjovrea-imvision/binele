# myapp/urls.py
from django.urls import path
from .views import my_view, client_data, scan_page

urlpatterns = [
    path('hello/', my_view, name='hello'),
    path('client/', client_data, name="Non-Muhahaha"),
    path('scan/', scan_page, name="Muhahahaha?"),
]