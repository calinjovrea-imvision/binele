from django.shortcuts import render

# Create your views here.
from django.http import JsonResponse

import requests
from bs4 import BeautifulSoup
from urllib.parse import urlparse
from django.http import JsonResponse

def my_view(request):
    data = {"message": "Hello, World!"}
    return JsonResponse(data)

def client_data(request):
    # Get client's IP address
    client_ip = request.META.get('REMOTE_ADDR')
    
    # Get user-agent (browser information)
    user_agent = request.META.get('HTTP_USER_AGENT')
    
    # You can also capture other details, such as HTTP headers, etc.
    headers = {key: value for key, value in request.META.items() if key.startswith('HTTP_')}
    
    # Prepare the data
    data = {
        "client_ip": client_ip,
        "user_agent": user_agent,
        "headers": headers,
    }
    
    return JsonResponse(data)

def is_valid_url(url):
    parsed_url = urlparse(url)
    return parsed_url.scheme in ["http", "https"] and bool(parsed_url.netloc)

def scan_html_for_vulnerabilities(url):
    try:
        # Check if URL is valid
        if not is_valid_url(url):
            return {"error": "Invalid URL provided."}

        # Make the GET request and ensure it returns a valid response
        response = requests.get(url, timeout=10)  # Set a timeout to avoid hanging
        if response.status_code != 200:
            return {"error": "Failed to retrieve page or page does not exist."}
        
        # Parse HTML content
        soup = BeautifulSoup(response.text, 'html.parser')

        # Start building the vulnerability report
        vulnerabilities = []

        # Check for missing HTTP headers
        headers = response.headers
        if 'X-Content-Type-Options' not in headers:
            vulnerabilities.append("Lipsa antetului X-Content-Type-Options.")
        if 'X-Frame-Options' not in headers:
            vulnerabilities.append("Lipsa antetului X-Frame-Options.")
        if 'Strict-Transport-Security' not in headers:
            vulnerabilities.append("Lipsa antetului Strict-Transport-Security.")
        if 'Content-Security-Policy' not in headers:
            vulnerabilities.append("Lipsa antetului Content-Security-Policy.")

        
        # Check for forms without anti-CSRF tokens (basic check for vulnerability)
        forms = soup.find_all('form')
        for form in forms:
            if not form.find('input', {'name': 'csrf_token'}):
                vulnerabilities.append("Form without anti-CSRF token.")
        
        # Detect if the page is using HTTP instead of HTTPS
        if not url.lower().startswith('https'):
            vulnerabilities.append("Page is served over HTTP instead of HTTPS.")

        vulnerabilities_ = [
            {
                "id": 1,
                "name": "Lipsa antetului X-Content-Type-Options.",
                "gravity": "Moderat până la Ridicat",
                "description": "Acest antet ajută la prevenirea interpretării greșite a fișierelor de către browsere ca un alt tip MIME. Fără acest antet, atacatorii pot exploata sniffing-ul MIME pentru a executa cod arbitrar, ducând la atacuri XSS sau alte tipuri de atacuri."
            },
            {
                "id": 2,
                "name": "Lipsa antetului X-Frame-Options.",
                "gravity": "Ridicat",
                "description": "Acest antet previne ca pagina ta să fie încorporată într-un iframe, reducând riscul de atacuri de tip Clickjacking. Fără el, un atacator poate păcăli utilizatorii să facă clic pe conținut malițios, ducând la furtul de date sau acțiuni neautorizate."
            },
            {
                "id": 3,
                "name": "Lipsa antetului Strict-Transport-Security.",
                "gravity": "Ridicat",
                "description": "HSTS forțează browserele să folosească HTTPS, protejând împotriva atacurilor de tip SSL stripping. Fără acest antet, atacatorii pot reduce conexiunea la HTTP, permițându-le să intercepteze informații sensibile."
            },
            {
                "id": 4,
                "name": "Lipsa antetului Content-Security-Policy.",
                "gravity": "Ridicat",
                "description": "CSP ajută la prevenirea atacurilor XSS prin restricționarea surselor de conținut. Fără acesta, atacatorii pot injecta scripturi malițioase, ducând la furtul de sesiuni, furt de date sau alte acțiuni malițioase."
            },
            {
                "id": 5,
                "name": "Formular fără token anti-CSRF.",
                "gravity": "Ridicat",
                "description": "Fără protecție CSRF, un atacator poate păcăli un utilizator să efectueze acțiuni neautorizate în numele acestuia. Aceasta este o vulnerabilitate serioasă, mai ales pentru formularele care gestionează date sensibile."
            }
        ]


        vuln_results = []
        for w in vulnerabilities:
            for j in vulnerabilities_:
                if w == j['name']:
                    vuln_results.append(j)
        
        return vuln_results
    except requests.exceptions.RequestException as e:
        # Handle exceptions such as network issues or invalid responses
        return {"error": f"Request failed: {str(e)}"}

import logging

def scan_page(request):
    url = request.GET.get('url', '').strip()
    logging.info(f"Received URL: {url}")
    
    if not url:
        return JsonResponse({"error": "No URL provided."}, status=400)
    
    result = scan_html_for_vulnerabilities(url)
    logging.info(f"Scan result: {result}")

    print(result)
    
    #if 'vulnerabilities' not in result:
    #    result['vulnerabilities'] = []  # Make sure there's always an array for vulnerabilities
    
    return JsonResponse({"vulnerabilities": result}, safe=False)




